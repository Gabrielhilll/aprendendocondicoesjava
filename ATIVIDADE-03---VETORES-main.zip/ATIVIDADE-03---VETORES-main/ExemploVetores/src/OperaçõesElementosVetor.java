import org.w3c.dom.ls.LSOutput;

public class OperaçõesElementosVetor {
    public static void main(String[] args) {

    int [] valores = new int[5];
    valores[0] = 10;
    valores[1] = 20;
    valores[2] = 30;
    valores[3] = 40;
    valores[4] = 50;

        System.out.println("O terceiro valor exibido na tela ; " + valores[2]);

}


}
