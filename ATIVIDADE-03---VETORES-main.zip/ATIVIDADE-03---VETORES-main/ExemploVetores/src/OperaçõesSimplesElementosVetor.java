public class OperaçõesSimplesElementosVetor {
    public static void main(String[] args) {
       int[] vetor = new int[4];
       vetor[0] = 10;
       vetor[1] = 20;
       vetor[2] = 30;
       vetor[3] = 40;


       int soma = vetor[3] + vetor[1];
        System.out.println("Soma: " + soma);

    }
}
