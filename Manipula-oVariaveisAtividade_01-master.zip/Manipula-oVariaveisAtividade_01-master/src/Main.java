
public class Main {
    public static void main(String[] args) {
       ////Declaração de variáveis////
        int idade= 30;
        int Idade= 20;
        double altura= 1.75;
        String Nome= "João Gabriel";

        boolean estuding = true;
        String estud= "Estudante";

        if (estuding) {

        }
        ////Operações simples/////

        int soma=idade+Idade;
        double multiplicacao=altura*2;

        ////Declaração de resultados////
        System.out.println("Eu sou: " + Nome);
        System.out.println("Sou um: " + estud);
        System.out.println("Minha idade é: " + Idade);
        System.out.println("Minha altura é: " + altura);
        System.out.println("A soma das idades é:" + soma);
        System.out.println("A multiplicação de altura é; " + multiplicacao);


    }
}